//
//  main.m
//  PluginDylibDemo
//
//  Created by 门超 on 2019/6/18.
//  Copyright © 2019 BGY. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
