//
//  PluginDylib.h
//  PluginDylib
//
//  Created by 门超 on 2019/6/18.
//  Copyright © 2019 BGY. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PluginDylib.
FOUNDATION_EXPORT double PluginDylibVersionNumber;

//! Project version string for PluginDylib.
FOUNDATION_EXPORT const unsigned char PluginDylibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PluginDylib/PublicHeader.h>
#import "Tools.h"
#import "PluginDylibViewController.h"
